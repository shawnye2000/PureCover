import sys
from flashrag.pipeline import BasicPipeline
from flashrag.utils import get_retriever, get_generator
sys.path.append('../ReST-MCTS/')
from MCTS.task import MCTS_Task
from tqdm import tqdm, trange

from models.get_response import *
import os
from flashrag.prompt import PromptTemplate
# os.environ['CUDA_VISIBLE_DEVICES'] = '0'
import json
import numpy as np
import torch
import torch.nn as nn
from torch.nn.parallel import DataParallel
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer, AdamW
from sklearn.metrics import accuracy_score
from torch.utils.data import DataLoader, Dataset
import pandas as pd
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
import sys
# sys.path.append('/home/xiaopeng_ye/experiment/o1agent/FlashRAG/ReST-MCTS/PRM/')
sys.path.append('/new_disk2/xiaopeng_ye/experiment/o1agent/FlashRAG/ReST-MCTS/PRM')
from model import Mistral_VM, read_json
from dataset import MyDataset
# from metric import accuracy
# '/new_disk2/xiaopeng_ye/experiment/Agent4Fairness/Qwen2.5-0.5B-Instruct'
path = "/home/xiaopeng_ye/LLMs/Qwen2.5-0.5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(path,
                                          padding=True,
                                              trust_remote_code=True)
base_model = AutoModelForCausalLM.from_pretrained(path,
                                                  trust_remote_code=True,
                                                  device_map='cuda',
                                                  torch_dtype=torch.float16).eval()  # .cuda()
tokenizer.pad_token = tokenizer.eos_token

import math
def sigmoid(x):
    return 1 / (1 + math.exp(-x))

def prm_verify(y, question, checkpoint_path = '/new_disk2/xiaopeng_ye/experiment/o1agent/FlashRAG/ReST-MCTS/PRM/records/Qwen/hotpotqa_VM_best_checkpoint_contro.pt'):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    vocab_size = base_model.config.vocab_size
    batch_size = 1
    test_json = [{
        'prompt_answer': f"""You are an expert in analyzing user query optimization solutions. 
        Based on the user query and the current optimization solution, provide the reward of the solution as a numerical score from 0 to 1.
        Do not output anything other than the numerical value.
        Query: {question} 
        Solution: {y} 
        Reward:
        """,
        'label': -1
    }]
    test_dataset = MyDataset(test_json, tokenizer)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size)

    # Load the best model for inference
    best_model = Mistral_VM(base_model, vocab_size)
    checkpoint_file_path = checkpoint_path
    if torch.cuda.device_count() > 1:
        best_model = DataParallel(best_model, device_ids=[0, 1])
        checkpoint = torch.load(checkpoint_file_path,
                                map_location=lambda storage, loc: storage.cuda(0))
    else:
        checkpoint = torch.load(checkpoint_file_path)
    best_model.load_state_dict(checkpoint)
    best_model.to(device)
    best_model.eval()

    # Perform inference
    test_preds = []
    # test_labels = []
    with torch.no_grad():
        for batch in tqdm(test_dataloader):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            # labels = batch['label'].to(dtype=torch.float32).to(device)
            outputs = best_model(input_ids=input_ids, attention_mask=attention_mask)
            test_preds.extend(outputs.tolist())
            # test_labels.extend(labels.tolist())
        inference_result = test_preds[0]
        print(f"Inference results:{inference_result}")
        # sigmoid_result = sigmoid(test_preds[0])
        # print(f'sigmoid results:{sigmoid_result}')
    return inference_result



class WOPRMPipeline(BasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None):
    # Load your own components
    super().__init__(config, prompt_template)
    if generator is None:
      self.generator = get_generator(config)
    else:
      self.generator = generator

    if retriever is None:
      self.retriever = get_retriever(config)
    else:
      self.retriever = retriever

    self.use_fid = config["use_fid"]



  def get_topk_docs(self, docs, scores, k):
    # 将 docs 和 scores 配对为元组列表
    doc_score_pairs = list(zip(docs, scores))

    # 按 score 排序，score 从高到低
    sorted_docs = sorted(doc_score_pairs, key=lambda x: x[1], reverse=True)

    # 取出前 k 个文档及其对应的 score
    top_k_docs = sorted_docs[:k]
    # print(f'topk_docs:{top_k_docs}')
    # 分别返回 top k 的文档和它们的 score
    top_k_docs_only = [doc for doc, score in top_k_docs]
    top_k_scores_only = [score for doc, score in top_k_docs]

    return top_k_docs_only, top_k_scores_only

  def document_rerank(self, retrieval_results, retrieval_scores):
    topk = self.config['rerank_topk']
    print(f'rerank_topk:{topk}')
    least_doc_per_query = 1
    chosen_document = []
    chosen_document_scores = []
    rest_document = []
    rest_document_scores = []
    for query_docs, query_doc_scores in zip(retrieval_results, retrieval_scores):
      chosen_document.extend(query_docs[:least_doc_per_query])
      chosen_document_scores.extend(query_doc_scores[:least_doc_per_query])
      rest_document.extend(query_docs[least_doc_per_query:])
      rest_document_scores.extend(query_doc_scores[least_doc_per_query:])

    if len(chosen_document) >= topk:
      chosen_document = chosen_document[:topk]
      chosen_document_scores = chosen_document_scores[:topk]
    else:
      remain_doc_num = topk - len(chosen_document)
      remain_docs, remain_scores = self.get_topk_docs(docs=rest_document,
                                                       scores=rest_document_scores,
                                                       k=remain_doc_num)
      chosen_document.extend(remain_docs)
      chosen_document_scores.extend(remain_scores)

    return [chosen_document], [chosen_document_scores]

  def prm_guided_beam_search(self, query, task, beam_size=3):
    # 初始beam：序列为空，得分=0
    beams = [{'tokens': '', 'step': 0,  'score': -999}]
    max_steps = 4
    for s in range(max_steps):
      new_beams = beams.copy()
      for beam in beams:
        # 生成下一token候选
        candidates = task.get_next_steps(beam['tokens'], beam['step']+1, n=3)
        for token in candidates:
          new_tokens = beam['tokens'] + token
          # 计算语言模型得分
          # lm_score = beam['score'] + log_prob
          # PRM评分（输入当前部分序列）
          prm_score = prm_verify(question=query, y=new_tokens)
          # 综合得分
          total_score = prm_score
          print(f'xxxxxxstep:{token}.  score:{total_score}')
          new_beams.append({'tokens': new_tokens, 'step': beam['step']+1 ,'score': total_score})
      # 保留Top-K beams
      beams = sorted(new_beams, key=lambda x: -x['score'])[:beam_size]
      print(f'best_score:{beams[0]["score"]} best query:{beams[0]["tokens"]}')
      print(f'beams:{beams}')
    # 返回最高分序列
    return beams[0]['tokens']

  def load_prompt(self):
    GENERATE_INSTRUCT = (
    """You can choose from the following actions: 
- <Rewrite>, when the query is vague or lacks specificity, has unclear syntax or missing context, or does not leverage prior conversation history, [Rewrite] the user's query to better reflect user's intention;
    Example: Input Query: 'What are the best deep learning models?'   
             <Rewrite>: ['What are the latest state-of-the-art deep learning models in 2024, particularly in NLP, computer vision, and recommendation systems?']

- <Decompose>, when the query is too complex or contains multiple sub-questions, requires retrieving information from different sources or perspectives, or involves reasoning that can be broken into simpler steps, decompose the query into separate sub-queries; 
    Example: Input Query: 'What profession does Nicholas Ray and Elia Kazan have in common?', 
             <Decompose>: ["What was Nicholas Ray’s profession?", "What was Elia Kazan’s profession?"]

- <Expand>, when the query is too short and may not return enough relevant documents, lacks key background details, or could benefit from additional context or related concepts, expand the query;
    Example: Input Query: 'How to improve LLM inference efficiency?', 
             <Expand>:  ['What are optimization techniques like quantization, distillation, and pruning?']
             
- <End>, if you think there is no room to optimize, you can end the process.

The format of the output is:
"
Existing Steps:
Step 1: Analysis: ...
        Action: <...>: [...]
Step 2: Analysis: ...
        Action: <...>: [...]
Step 3: Analysis: ...
        Action: <...>: [...]"

Query:{question}
"""
    )
    self.process_query_template = PromptTemplate(self.config,
                                           system_prompt="You are a query optimization expert. Your goal is to optimize the query step by step, making it can retrieve relevant and comprehensive documents to answer the user's question. ",
                                           user_prompt=GENERATE_INSTRUCT
                                           )



  def query_optimization(self, input_query):
    self.load_prompt()
    # self.query_generator = get_generator({
    #   "framework": 'openai',
    #   "generator_model": "/new_disk2/xiaopeng_ye/experiment/Agent4Fairness/Meta-Llama-3-8B-Instruct",
    #   "openai_setting":{
    #     "api_key": "EMPTY",
    #     "base_url": "http://localhost:8000/v1"},
    #   "generator_batch_size": 4,
    #   "generation_params":{
    #   "do_sample": True,
    #     "max_tokens": 1024,
    # "temperature": 1.0}
    # })
    # print(self.config)
    # questions = []

    input_prompts = [
      self.process_query_template.get_string(question=q)
      for q in input_query
    ]


    opt_query_list = self.generator.generate(input_prompts)

    task = MCTS_Task(data ="", data_dict={}, history='', base_model_gpt = self.config['generator_model'])
    extract_queries_list = []
    for i, y in enumerate(opt_query_list):
      query_list = task.get_processed_queries(y)
      if query_list == []:
        print(f'output query:{[input_query[i]]}')
        extract_queries_list.append([input_query[i]])
      else:
        query_list = [i for q in query_list for i in q.split('and') ]
        query_list = [i for q in query_list for i in q.split('And')]
        print(f'output query:{query_list}')
        extract_queries_list.append(query_list)

    return extract_queries_list

  def run(self, dataset, do_eval=True, pred_process_fun=None):
    print(self.config)
    input_query = dataset.question
    optimized_query_lists = self.query_optimization(input_query)
    print(f'retrieving...')
    all_query_docs = []
    all_query_scores = []
    dataset.update_output("optimized_query", optimized_query_lists)

    for opted_query_list in optimized_query_lists:
      retrieval_results, retrieval_scores = self.retriever.batch_search(opted_query_list, return_score=True)
      # rerank_results, rerank_scores = self.document_rerank(retrieval_results, retrieval_scores)
      all_query_docs.append([item for sublist in retrieval_results for item in sublist])#.append(rerank_results[0])
      all_query_scores.append([item for sublist in retrieval_scores for item in sublist])#.append(rerank_scores[0])
      print(f'len_all_query_docs:{len(all_query_docs)}')

      # print(f'rerank_result:{rerank_results}')
      # print(f'rerank_scores:{rerank_scores}')

    dataset.update_output("retrieval_result", all_query_docs)

    if not self.use_fid:
      input_prompts = [
        self.prompt_template.get_string(question=q, retrieval_result=r)
        for q, r in zip(dataset.question, dataset.retrieval_result)
      ]

    if self.use_fid:
      print("Use FiD generation")
      input_prompts = []
      for item in dataset:
        q = item.question
        docs = item.retrieval_result
        input_prompts.append([q + " " + doc['contents'] for doc in docs])
    dataset.update_output("prompt", input_prompts)

    # delete used refiner to release memory
    print(f'generating...')
    pred_answer_list = self.generator.generate(input_prompts)
    dataset.update_output("pred", pred_answer_list)

    dataset = self.evaluate(dataset, do_eval=do_eval, pred_process_fun=pred_process_fun)
    print(f'dataset:{dataset}')
    return dataset  #.output["metric_score"]['f1']




