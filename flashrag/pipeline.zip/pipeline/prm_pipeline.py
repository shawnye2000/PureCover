from flashrag.pipeline import SFTPipeline
from torch.nn.parallel import DataParallel
from transformers import AutoModelForCausalLM, AutoTokenizer
# from models.get_response import *

from tqdm import tqdm
from flashrag.dataset.dataset import Dataset
import sys
sys.path.append('/home/xiaopeng_ye/experiment/o1agent/FlashRAG/ReST-MCTS/PRM/')
# sys.path.append('/new_disk2/xiaopeng_ye/experiment/o1agent/FlashRAG/ReST-MCTS/PRM')
from model import Mistral_VM, read_json
from dataset import MyDataset
import torch

import math
def sigmoid(x):
    return 1 / (1 + math.exp(-x))

def prm_verify(y, question, summary, checkpoint_path, tokenizer, base_model):
    if not checkpoint_path:
      raise ValueError('No Checkpoint')
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    vocab_size = base_model.config.vocab_size
    batch_size = 1
    test_json = [{
        'prompt_answer': f"""You are an expert in analyzing user query optimization solutions. 
        Based on the user query and the current optimization solution, provide the reward of the solution as a numerical score from 0 to 1.
        Do not output anything other than the numerical value.
        Query: {question} 
        Solution: {y} 
        Optimized_query: {summary}
        Reward:
        """,
        'label': -1
    }]
    test_dataset = MyDataset(test_json, tokenizer)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size)

    # Load the best model for inference
    best_model = Mistral_VM(base_model, vocab_size)
    checkpoint_file_path = checkpoint_path
    if torch.cuda.device_count() > 1:
        best_model = DataParallel(best_model, device_ids=[0, 1])
        checkpoint = torch.load(checkpoint_file_path,
                                map_location=lambda storage, loc: storage.cuda(0))
    else:
        checkpoint = torch.load(checkpoint_file_path)
    best_model.load_state_dict(checkpoint)
    best_model.to(device)
    best_model.eval()

    # Perform inference
    test_preds = []
    # test_labels = []
    with torch.no_grad():
        for batch in tqdm(test_dataloader):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            # labels = batch['label'].to(dtype=torch.float32).to(device)
            outputs = best_model(input_ids=input_ids, attention_mask=attention_mask)
            test_preds.extend(outputs.tolist())
            # test_labels.extend(labels.tolist())
        inference_result = test_preds[0]
        print(f"Inference results:{inference_result}")
        # sigmoid_result = sigmoid(test_preds[0])
        # print(f'sigmoid results:{sigmoid_result}')
    return inference_result



class PRMPipeline(SFTPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)
    path = "/home/xiaopeng_ye/LLMs/Qwen2.5-0.5B-Instruct"  # '/new_disk2/xiaopeng_ye/experiment/Agent4Fairness/Qwen2.5-0.5B-Instruct'
    self.tokenizer = AutoTokenizer.from_pretrained(path,
                                              padding=True,
                                              trust_remote_code=True)
    self.base_model = AutoModelForCausalLM.from_pretrained(path,
                                                      trust_remote_code=True,
                                                      device_map='cuda',
                                                      torch_dtype=torch.float16).eval()  # .cuda()
    self.tokenizer.pad_token = self.tokenizer.eos_token

  def select_best_prm_querylist(self, query, solutions, query_lists):
    scores = []
    for solution, query_list in zip(solutions, query_lists):
        prm_score = prm_verify(question=query, y=solutions, summary=query_list,
                               checkpoint_path=self.config['prm_path'],
                               tokenizer=self.tokenizer, base_model=self.base_model)
        scores.append(prm_score)
    print(f'scores: {scores}')
    best_list = query_lists[scores.index(max(scores))]
    print(f'best prm querylist: {best_list}')
    return best_list

  def query_rewrite(self, queries):
    print(self.config)
    optimized_query_lists = []
    for question in tqdm(queries):
      outputs = self.get_sampled_solutions(question, n=5)
      print(f'solutions: {outputs}')
      possible_lists = []
      for output in outputs:
        opt_query_list = self.get_processed_queries(output)
        possible_lists.append(opt_query_list)
      opt_query_list = self.select_best_prm_querylist(question,
                                                      solutions=outputs,
                                                      query_lists=possible_lists)
      if isinstance(opt_query_list, list) and opt_query_list and opt_query_list[0]:
          # opt_query_list = merge_split_strings(opt_query_list)
          print(f'final querylist: {opt_query_list} type: {type(opt_query_list)}')
          optimized_query_lists.append(opt_query_list)
      else:
          # raise ValueError('Query List Not Found')
          optimized_query_lists.append([question])
          print(f'Query List Not Found')
    return optimized_query_lists
