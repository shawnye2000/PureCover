from flashrag.pipeline import SFTPipeline

from collections import Counter
# from models.get_response import *

from tqdm import tqdm
from flashrag.dataset.dataset import Dataset


class SelfTrainPipeline(SFTPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def query_optimization(self, input_query):
    query_solution_dict = {}
    for question in tqdm(input_query, total=len(input_query), desc="Query Rewriting:"):
      outputs = self.get_solution(question, n=10)
      possible_lists = []
      for output in outputs:
        query_list = self.get_processed_queries(output)
        if query_list == []:
            possible_lists.append({'solution': output,
                                   'query_list': ['']})
        else:
            possible_lists.append({'solution': output,
                               'query_list': query_list})
      query_solution_dict[question] = possible_lists
    return query_solution_dict

  def generate_samples(self, dataset, do_eval=True):
    ids = dataset.id
    questions = dataset.question
    golden_answers = dataset.golden_answers
    query_solution_dict = self.query_optimization(questions)

    for i, (question, solution_list) in tqdm(enumerate(query_solution_dict.items()), total=len(query_solution_dict)):
        test_data = Dataset(data=[{
            "id": ids[i],
            "question": questions,
            "golden_answers": golden_answers[i],
        }])

        for n, solu_dict in enumerate(solution_list):
            solution = solu_dict['solution']
            query_list = solu_dict['query_list']
            result = self.query_run(test_data, query_list,  do_eval=True)
            outscore = (result.metric_score[0]['f1'] + result.metric_score[0]['em'] + result.metric_score[0][
                'acc'] )/3
            print(f'outscore: {outscore}')
            query_solution_dict[question][n]['score'] = outscore
    return query_solution_dict
    #
    # print(f'retrieving...')
    # all_query_docs = []
    # all_query_scores = []
    # for opted_query_list in optimized_query_lists:
    #   retrieval_results, retrieval_scores = self.retriever.batch_search(opted_query_list, return_score=True)
    #   # rerank_results, rerank_scores = self.document_rerank(retrieval_results, retrieval_scores)
    #   all_query_docs.append([item for sublist in retrieval_results for item in sublist])# (rerank_results[0]) #
    #   all_query_scores.append([item for sublist in retrieval_scores for item in sublist])
    #
    # dataset.update_output("retrieval_result", all_query_docs)
    #
    # if not self.use_fid:
    #   input_prompts = [
    #     self.prompt_template.get_string(question=q, retrieval_result=r)
    #     for q, r in zip(dataset.question, dataset.retrieval_result)
    #   ]
    #
    # dataset.update_output("prompt", input_prompts)
    #
    # # delete used refiner to release memory
    # print(f'generating...')
    # pred_answer_list = self.generator.generate(input_prompts)
    # dataset.update_output("pred", pred_answer_list)
    #
    # dataset = self.evaluate(dataset, do_eval=do_eval, pred_process_fun=pred_process_fun)
    # print(f'dataset:{dataset}')
    # return dataset  #.out
    #
