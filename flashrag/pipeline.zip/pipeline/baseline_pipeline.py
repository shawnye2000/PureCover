from flashrag.pipeline.query_basic_pipeline import QueryBasicPipeline
from flashrag.utils import get_retriever, get_generator
from flashrag.prompt import PromptTemplate

class LLMRewritePipeline(QueryBasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)
    self.load_prompts()

  def load_prompts(self):
    REWRITE_INSTRUCT = (
      "Query: {query}\n"
      "Rewrited Query:"
    )

    self.rewrite_template = PromptTemplate(self.config,
                                           system_prompt="Please rewrite the user query to reflect the user question and intention more clearly.\
                                                         Only give me the rewrited query and do not output any other words.",
                                           user_prompt=REWRITE_INSTRUCT
                                           )
  def query_rewrite(self, queries):
    rewrite_prompts = [
        self.rewrite_template.get_string(query=q)
        for q in queries
      ]
    rewrited_query_list = self.query_generator.generate(rewrite_prompts)
    return rewrited_query_list



class InfoCQRPipeline(QueryBasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def load_prompts(self):
    Instruction = "Given a question and its context, decontextualize the question by addressing coreference and omission issues. The resulting question should retain its original meaning and be as informative as possible, and should not duplicate any previously asked questions in the context."

    e1 = "Context: [Q: When was Born to Fly released? A: Sara Evans's third studio album, Born to Fly, was released on October 10, 2000.]\nQuestion: Was Born to Fly well received by critics?\nRewrite: Was Born to Fly well received by critics?"

    e2 = "Context: [Q: When was Keith Carradine born? A: Keith Ian Carradine was born August 8, 1949. Q: Is he married? A: Keith Carradine married Sandra Will on February 6, 1982.]\nQuestion: Do they have any children?\nRewrite: Do Keith Carradine and Sandra Will have any children?"

    e3 = "Context: [Q: Who proposed that atoms are the basic units of matter? A: John Dalton proposed that each chemical element is composed of atoms of a single, unique type, and they can combine to form more complex structures called chemical compounds.]\nQuestion: How did the proposal come about?\nRewrite: How did John Dalton's proposal that each chemical element is composed of atoms of a single unique type, and they can combine to form more complex structures called chemical compounds come about?"

    e4 = "Context: [Q: What is it called when two liquids separate? A: Decantation is a process for the separation of mixtures of immiscible liquids or of a liquid and a solid mixture such as a suspension. Q: How does the separation occur? A: The layer closer to the top of the container-the less dense of the two liquids, or the liquid from which the precipitate or sediment has settled out-is poured off.]\nQuestion: Then what happens?\nRewrite: Then what happens after the layer closer to the top of the container is poured off with decantation?"

    gpt_rewrite_INSTRUCT = (
      f"{Instruction}\n\n{e1}\n\n{e2}\n\n{e3}\n\n{e4}\n\n"
      "Context: []\nQuestion: {query}\nRewrite: "
    )

    self.gpt_rewrite_template = PromptTemplate(self.config,
                                           system_prompt="",
                                           user_prompt=gpt_rewrite_INSTRUCT
                                           )

    Instruction = "Given a question and its context and a rewrite that decontextualizes the question, edit the rewrite to create a revised version that fully addresses coreferences and omissions in the question without changing the original meaning of the question but providing more information. The new rewrite should not duplicate any previously asked questions in the context. If there is no need to edit the rewrite, return the rewrite as-is."

    e1 = "Context: [Q: When was Born to Fly released? A: Sara Evans's third studio album, Born to Fly, was released on October 10, 2000.]\nQuestion: Was Born to Fly well received by critics?\nRewrite: Was Born to Fly well received by critics?\nEdit: Was Born to Fly well received by critics?"

    e2 = "Context: [Q: When was Keith Carradine born? A: Keith Ian Carradine was born August 8, 1949. Q: Is he married? A: Keith Carradine married Sandra Will on February 6, 1982.]\nQuestion: Do they have any children?\nRewrite: Does Keith Carradine have any children?\nEdit: Do Keith Carradine and Sandra Will have any children?"

    e3 = "Context: [Q: Who proposed that atoms are the basic units of matter? A: John Dalton proposed that each chemical element is composed of atoms of a single, unique type, and they can combine to form more complex structures called chemical compounds.]\nQuestion: How did the proposal come about?\nRewrite: How did John Dalton's proposal come about?\nEdit: How did John Dalton's proposal that each chemical element is composed of atoms of a single unique type, and they can combine to form more complex structures called chemical compounds come about?"

    e4 = "Context: [Q: What is it called when two liquids separate? A: Decantation is a process for the separation of mixtures of immiscible liquids or of a liquid and a solid mixture such as a suspension. Q: How does the separation occur? A: The layer closer to the top of the container-the less dense of the two liquids, or the liquid from which the precipitate or sediment has settled out-is poured off.]\nQuestion: Then what happens?\nRewrite: Then what happens after the layer closer to the top of the container is poured off?\nEdit: Then what happens after the layer closer to the top of the container is poured off with decantation?"

    editor_REWRITE_INSTRUCT = (
      f"{Instruction}\n\n{e1}\n\n{e2}\n\n{e3}\n\n{e4}\n",
      "Context: []\nQuestion: {query}\nRewrite: {gpt_rewrite}\nEdit: "
    )

    self.editor_rewrite_template = PromptTemplate(self.config,
                                           system_prompt="",
                                           user_prompt=editor_REWRITE_INSTRUCT
                                           )
  def query_rewrite(self, queries):

    gpt_rewrite_prompts = [
        self.gpt_rewrite_template.get_string(query=q)
        for q in queries
      ]
    gpt_rewrited_query_list = self.query_generator.generate(gpt_rewrite_prompts)

    editor_rewrite_prompts = [
        self.editor_rewrite_template.get_string(query=q, gpt_rewrite=g)
        for q, g in zip(queries, gpt_rewrited_query_list)
      ]
    editor_rewrited_query_list = self.query_generator.generate(editor_rewrite_prompts)
    return editor_rewrited_query_list


class HydePipeline(QueryBasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def load_prompts(self):
    GENERATE_INSTRUCT = (
      "Please write a passage to answer the question."
      "Question: {question} \n"
      "Passage:"
    )
    self.generate_fake_doc_template = PromptTemplate(self.config,
                                           system_prompt="",
                                           user_prompt=GENERATE_INSTRUCT
                                           )

  def generate_fake_docs(self, query, k):
    rewrite_prompts = [
        self.generate_fake_doc_template.get_string(question=query)
        for _ in range(k)
      ]
    fake_doc_list = self.query_generator.generate(rewrite_prompts)
    return fake_doc_list


  def run(self, dataset, do_eval=True, pred_process_fun=None):
    input_query = dataset.question
    retrieval_results = []
    for i, q in enumerate(input_query):
      fake_docs = self.generate_fake_docs(q, k=5)
      result = self.retriever.hyde_search(q, fake_docs,
                                          num=self.config['retrieval_topk'],
                                          return_score=False)
      retrieval_results.append(result)
    dataset.update_output("retrieval_result", retrieval_results)
    input_prompts = [
        self.prompt_template.get_string(question=q, retrieval_result=r)
        for q, r in zip(input_query, dataset.retrieval_result)
      ]
    dataset.update_output("prompt", input_prompts)

    # delete used refiner to release memory
    pred_answer_list = self.generator.generate(input_prompts)
    dataset.update_output("pred", pred_answer_list)

    dataset = self.evaluate(dataset, do_eval=do_eval, pred_process_fun=pred_process_fun)

    return dataset


class Query2DocPipeline(QueryBasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def load_prompts(self):
    GENERATE_INSTRUCT = (
      "Please write a passage to answer the question."
      "Question: {question} \n"
      "Passage:"
    )
    self.generate_fake_doc_template = PromptTemplate(self.config,
                                           system_prompt="",
                                           user_prompt=GENERATE_INSTRUCT
                                           )

  def generate_fake_docs(self, query, k=1):
    rewrite_prompts = [
        self.generate_fake_doc_template.get_string(question=query)
        for _ in range(k)
      ]
    fake_doc_list = self.query_generator.generate(rewrite_prompts)
    return fake_doc_list


  def run(self, dataset, do_eval=True, pred_process_fun=None):
    input_query = dataset.question
    extended_query = []
    for i, q in enumerate(input_query):
      fake_docs = self.generate_fake_docs(q, k=1)[0]
      new_query = '{} {}'.format(' '.join([q for _ in range(5)]), fake_docs)
      extended_query.append(new_query)
    retrieval_results = self.retriever.batch_search(extended_query)

    dataset.update_output("retrieval_result", retrieval_results)

    input_prompts = [
        self.prompt_template.get_string(question=q, retrieval_result=r)
        for q, r in zip(input_query, dataset.retrieval_result)
      ]
    # delete used refiner to release memory
    pred_answer_list = self.generator.generate(input_prompts)
    dataset.update_output("pred", pred_answer_list)

    dataset = self.evaluate(dataset, do_eval=do_eval, pred_process_fun=pred_process_fun)

    return dataset


class Query2CoTPipeline(Query2DocPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def load_prompts(self):
    GENERATE_INSTRUCT = (
      "Please write a passage to answer the question. Lets Think Step by Step."
      "Question: {question} \n"
      "Passage:"
    )
    self.generate_fake_doc_template = PromptTemplate(self.config,
                                           system_prompt="",
                                           user_prompt=GENERATE_INSTRUCT
                                           )

