from flashrag.pipeline import BasicPipeline
from flashrag.utils import get_retriever, get_generator
from collections import Counter
from flashrag.prompt import PromptTemplate
# from models.get_response import *
import gc, ray
import torch
import contextlib
from tqdm import tqdm
from vllm.distributed.parallel_state import destroy_model_parallel, destroy_distributed_environment
# import os
# os.environ["TOKENIZERS_PARALLELISM"] = "false"

class QueryBasicPipeline(BasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    super().__init__(config, prompt_template)
    if generator is None:
      self.generator = get_generator(config)
    else:
      self.generator = generator
    if query_generator is None:
      self.query_generator = get_generator(config)
    else:
      self.query_generator = query_generator
    if retriever is None:
      self.retriever = get_retriever(config)
    else:
      self.retriever = retriever

    self.use_fid = config["use_fid"]
    self.load_prompts()

  def load_prompts(self):
      pass

  def get_topk_docs(self, docs, scores, k):
    # 将 docs 和 scores 配对为元组列表
    doc_score_pairs = list(zip(docs, scores))

    # 按 score 排序，score 从高到低
    sorted_docs = sorted(doc_score_pairs, key=lambda x: x[1], reverse=True)

    # 取出前 k 个文档及其对应的 score
    top_k_docs = sorted_docs[:k]
    # print(f'topk_docs:{top_k_docs}')
    # 分别返回 top k 的文档和它们的 score
    top_k_docs_only = [doc for doc, score in top_k_docs]
    top_k_scores_only = [score for doc, score in top_k_docs]

    return top_k_docs_only, top_k_scores_only

  def document_rerank(self, retrieval_results, retrieval_scores):
    topk = self.config['rerank_topk']
    print(f'rerank_topk:{topk}')
    least_doc_per_query = 1
    chosen_document = []
    chosen_document_scores = []
    rest_document = []
    rest_document_scores = []
    for query_docs, query_doc_scores in zip(retrieval_results, retrieval_scores):
      chosen_document.extend(query_docs[:least_doc_per_query])
      chosen_document_scores.extend(query_doc_scores[:least_doc_per_query])
      rest_document.extend(query_docs[least_doc_per_query:])
      rest_document_scores.extend(query_doc_scores[least_doc_per_query:])

    if len(chosen_document) >= topk:
      chosen_document = chosen_document[:topk]
      chosen_document_scores = chosen_document_scores[:topk]
    else:
      remain_doc_num = topk - len(chosen_document)
      remain_docs, remain_scores = self.get_topk_docs(docs=rest_document,
                                                       scores=rest_document_scores,
                                                       k=remain_doc_num)
      chosen_document.extend(remain_docs)
      chosen_document_scores.extend(remain_scores)

    return [chosen_document], [chosen_document_scores]

  def clean_query_generator(self):
      destroy_model_parallel()
      destroy_distributed_environment()
      del self.query_generator.model.llm_engine.model_executor
      del self.query_generator.model
      del self.query_generator
      gc.collect()
      torch.cuda.empty_cache()
      with contextlib.suppress(AssertionError):
        torch.distributed.destroy_process_group()
      ray.shutdown()
      print("Successfully delete the llm pipeline and free the GPU memory!")


  def query_rewrite(self, queries):
    pass

  def run(self, dataset, do_eval=True, pred_process_fun=None):
    input_query = dataset.question
    rewrited_query = self.rewrite_queries(input_query)
    retrieval_results = self.retriever.batch_search(rewrited_query)
    dataset.update_output("retrieval_result", retrieval_results)

    input_prompts = [
        self.prompt_template.get_string(question=q, retrieval_result=r)
        for q, r in zip(rewrited_query, dataset.retrieval_result)
      ]
    # delete used refiner to release memory
    pred_answer_list = self.generator.generate(input_prompts)
    dataset.update_output("pred", pred_answer_list)

    dataset = self.evaluate(dataset, do_eval=do_eval, pred_process_fun=pred_process_fun)

    return dataset