from flashrag.pipeline.sft_pipeline import SFTPipeline
from collections import Counter
from tqdm import tqdm

class SelfConsistencyPipeline(SFTPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def select_most_frequent_query_list(self, query_lists):
    sample_counts = Counter([tuple(l) for l in query_lists])
    # 选择出现次数最多的样本
    opt_query_list, _ = sample_counts.most_common(1)[0]
    opt_query_list = list(opt_query_list)
    if (not opt_query_list) or (len(sample_counts) == len(query_lists)):
        print("All samples are unique.")
        return max(query_lists, key=len)
    else:
        return opt_query_list

  def query_rewrite(self, input_query):
    print(self.config)
    optimized_query_lists = []
    for question in tqdm(input_query):
      outputs = self.get_solution(question, n=5)
      print(f'solutions: {outputs}')
      possible_lists = []
      for output in outputs:
        opt_query_list = self.get_processed_queries(output)
        if opt_query_list:
            possible_lists.append(opt_query_list)
      opt_query_list = self.select_most_frequent_query_list(possible_lists)
      if isinstance(opt_query_list, list) and opt_query_list and opt_query_list[0]:
          # opt_query_list = merge_split_strings(opt_query_list)
          print(f'final querylist: {opt_query_list} type: {type(opt_query_list)}')
          optimized_query_lists.append(opt_query_list)
      else:
          # raise ValueError('Query List Not Found')
          optimized_query_lists.append([question])
          print(f'Query List Not Found')
    return optimized_query_lists

