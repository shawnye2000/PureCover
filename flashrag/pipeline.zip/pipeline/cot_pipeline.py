from flashrag.pipeline.sft_pipeline import SFTPipeline

cot_prompt = """Given a user query, your task is to optimize the query step-by-step in a clear and specific manner in order to retrieve comprehensive and relevant documents.
The format of the solution is limited to: "Solution: ...\nSummary: The final answer is $...$"
Please optimize the query step-by-step, and finally summarize the final query in the form of ['optimized_query1', 'optimized_query2', ...].
Query: """

class CoTPipeline(SFTPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    # Load your own components
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def get_solution(self, query, n=3, temperature=0.95, do_sample=True):
      solution_prompts = [
          cot_prompt + query
      ]
      # print(f'solution extracted: {solution_prompts}')
      output_list = self.query_generator.generate(solution_prompts,
                                          n=n,
                                          temperature=temperature,
                                          return_raw_output=True)
      output = output_list[0]
      samples = [output.outputs[i].text for i in range(n)]
      return samples