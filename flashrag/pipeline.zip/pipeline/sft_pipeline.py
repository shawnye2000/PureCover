from flashrag.pipeline.query_basic_pipeline import QueryBasicPipeline
from flashrag.prompt import PromptTemplate
from tqdm import tqdm


system_prompt = """You are an expert at optimize user query for the retrieval generative generation process.
Your goal is to optimize the query step by step, making it can retrieve relevant documents to answer the user's question.
    """
instruction = """You can **only** choose from the following actions:
- <Rewrite>, when the query is vague or lacks specificity, has unclear syntax or missing context, or does not leverage prior conversation history, [Rewrite] the user's query to better reflect user's intention;
    Example: Input Query: 'What are the best deep learning models?'   
             <Rewrite>: ['What are the latest state-of-the-art deep learning models in 2024, particularly in NLP, computer vision, and recommendation systems?']

- <Decompose>, when the query is too complex or contains multiple sub-questions, requires retrieving information from different sources or perspectives, or involves reasoning that can be broken into simpler steps, [Decompose] the query into separate sub-queries; 
    Example: Input Query: 'What profession does Nicholas Ray and Elia Kazan have in common?', 
             <Decompose>: ["What was Nicholas Ray’s profession?", "What was Elia Kazan’s profession?"]

- <Expand>, when the query is too short and may not return enough relevant documents, lacks key background details, or could benefit from additional context or related concepts, [Expand] the query;
    Example: Input Query: 'How to improve LLM inference efficiency?', 
             <Expand>:  ['What are optimization techniques like quantization, distillation, and pruning?']

- <Disambiguate>, when the query is are ambiguous or have multiple potential interpretations, [Disambiguate] the query;
    Example: Input Query: 'Who is the 2024 Summer Olympics table tennis singles champion?', 
             <Disambiguate>:  ['Who is the women's singles champion in table tennis at the 2024 Summer Olympics?', 'Who is the men's singles champion in table tennisat the 2024 Summer Olympics?']

- <Abstract>, when the query requires not only an understanding of the facts but also the ability to comprehend and apply domain-specific reasoning integral to the context of the data, [Abstract] the query;
    Example: Input Query: 'How many times has China hosted the Olympic Games?', 
             <Abstract>:  ['The history of hosting the Olympic Games.']

- <End>, when there is no space left for further optimization, output <End>

 Assuming the output is n-steps, then the format of the output is:
"
Step 1: Analysis: ...
        Action: <...>: [...]
Step 2: Analysis: ...
        Action: <...>: [...]
Step 3: Analysis: ...
        Action: <...>: [...]
...
Step n: Action: <End>"
 Here is the input, please follow the restricted output format.

Query:{query}"""

import random
import re
import ast

def get_last_list_str(s):
    matches = re.findall(r'\[(.*?)\]', s)
    if matches:
        # 提取到的列表字符串
        return matches[-1]
    else:
        return ""

def extract_str_to_list(list_str):

    try:
        result = ast.literal_eval(list_str)
        # print(result)  # 输出: ['a', 'b']
        # print(type(result))  # 输出: <class 'list'>
        if not isinstance(result, list):
            return []
        else:
            if len(result) == 0:
                return []
            else:
                for sub_query in result:
                    if not isinstance(sub_query, str):
                        return []
        return result
    except Exception as e:
        print(f'Error Occur when extracting query:{e}')
        return []

import itertools

def merge_split_strings(lst):
    # 使用 itertools.chain 来合并所有子列表
    return list(itertools.chain(*[s.split('?') for s in lst]))


class SFTPipeline(QueryBasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None, query_generator=None):
    super().__init__(config, prompt_template, retriever, generator, query_generator)

  def load_prompts(self):
      repair_prompt = """You are given a malformed string that should represent a list, but due to formatting errors, it cannot be directly parsed. Please repair the string so that it follows the correct Python List[str] format. Output the repaired string in a format that can be correctly parsed by `eval()`.
                           Now, repair this malformed string and output the correct Python list string format.
                           **IMPORTANT NOTICE**: Please Only output the List[str], but nothing else!!!!
                           Input: "{list_str}"
                           Output:"""

      self.rewrite_template = PromptTemplate(self.config,
                                             system_prompt="",
                                             user_prompt=repair_prompt
                                             )

  def query_repairer(self, list_str):
      repair_prompts = [
          self.rewrite_template.get_string(list_str=list_str)
      ]
      rewrited_query_list = self.generator.generate(repair_prompts)
      return rewrited_query_list[0]

  def get_processed_queries(self, solution):
      last_list_str = get_last_list_str(solution)
      extracted_query = extract_str_to_list(last_list_str)
      cnt = 3
      while cnt > 0 and extracted_query == []:
          p = self.query_repairer(last_list_str)
          extracted_query = extract_str_to_list(p)
          if isinstance(extracted_query, list) and extracted_query and extracted_query[0]:
              break
          else:
              cnt -= 1
      print(f'Query extracted: {extracted_query}')
      return extracted_query

  def get_solution(self, query, n=3, temperature=0.95, do_sample=True):
      solution_prompts = [
          system_prompt + instruction + query
      ]
      # print(f'solution extracted: {solution_prompts}')
      output_list = self.query_generator.generate(solution_prompts,
                                          n=n,
                                          temperature=temperature,
                                          return_raw_output=True)
      output = output_list[0]

      samples = [output.outputs[i].text for i in range(n)]
      return samples

  def query_rewrite(self, input_query):
    print(self.config)
    optimized_query_lists = []
    for question in tqdm(input_query):
      output = self.get_solution(question, n=1)[0]
      print(f'solution: {output}')
      opt_query_list = self.get_processed_queries(output)
      if isinstance(opt_query_list, list) and opt_query_list and opt_query_list[0]:
          # opt_query_list = merge_split_strings(opt_query_list)
          print(f'final querylist: {opt_query_list} type: {type(opt_query_list)}')
          optimized_query_lists.append(opt_query_list)
      else:
          # raise ValueError('Query List Not Found')
          optimized_query_lists.append([question])
          print(f'Query List Not Found')
    return optimized_query_lists

  def query_run(self, dataset, query_list, do_eval=True, pred_process_fun=None):
    input_query = query_list
    print(f'retrieving...')
    retrieval_results, retrieval_scores = self.retriever.batch_search(input_query, return_score=True)
    retrieval_results = [[doc for sublist in retrieval_results for doc in sublist]]
    # retrieval_scores = [[score for sublist in retrieval_scores for score in sublist]]
    dataset.update_output("retrieval_result", retrieval_results)

    input_prompts = [
        self.prompt_template.get_string(question=q, retrieval_result=r)
        for q, r in zip(dataset.question, dataset.retrieval_result)
    ]
    # delete used refiner to release memory
    print(f'genertating...')
    pred_answer_list = self.generator.generate(input_prompts)
    dataset.update_output("pred", pred_answer_list)
    dataset = self.evaluate(dataset, do_eval=do_eval, pred_process_fun=pred_process_fun)
    print(f'dataset:{dataset}')
    return dataset  #.output["metric_score"]['f1']


  def run(self, dataset, do_eval=True, pred_process_fun=None, return_metric_dict=False):
    print(self.config)
    input_query = dataset.question
    optimized_query_lists = self.query_rewrite(input_query)
    print(f'retrieving...')
    all_query_docs = []
    all_query_scores = []
    for opted_query_list in optimized_query_lists:
      retrieval_results, retrieval_scores = self.retriever.batch_search(opted_query_list, return_score=True)
      # rerank_results, rerank_scores = self.document_rerank(retrieval_results, retrieval_scores)
      all_query_docs.append([item for sublist in retrieval_results for item in sublist])# (rerank_results[0]) #
      all_query_scores.append([item for sublist in retrieval_scores for item in sublist])

    dataset.update_output("retrieval_result", all_query_docs)

    input_prompts = [
        self.prompt_template.get_string(question=q, retrieval_result=r)
        for q, r in zip(dataset.question, dataset.retrieval_result)
      ]
    # delete used refiner to release memory
    print(f'generating...')
    pred_answer_list = self.generator.generate(input_prompts)
    dataset.update_output("pred", pred_answer_list)

    if return_metric_dict:
        dataset, eval_result = self.evaluate(dataset, do_eval=do_eval,
                                pred_process_fun=pred_process_fun,
                                return_metric_dict=True)
        return dataset, eval_result  # .out
    else:
        dataset = self.evaluate(dataset, do_eval=do_eval,
                                pred_process_fun=pred_process_fun,
                                return_metric_dict=False)
        return dataset


