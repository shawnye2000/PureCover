from flashrag.pipeline import BasicPipeline
from flashrag.utils import get_retriever, get_generator
from flashrag.prompt import PromptTemplate
import os
import pathlib



class RQRAGPipeline(BasicPipeline):
  def __init__(self, config, prompt_template=None, retriever=None, generator=None):
    # Load your own components
    super().__init__(config, prompt_template)
    if generator is None:
      self.generator = get_generator(config)
    else:
      self.generator = generator

    if retriever is None:
      self.retriever = get_retriever(config)
    else:
      self.retriever = retriever

    self.use_fid = config["use_fid"]
    self.load_prompts(config['dataset'])

  def load_prompts(self, dataset):
    system_prompt_dict = {
      "single_hop": "Please answer the question.",
      "multi-hop": "Given a question that requires multi-hop reasoning, you need to decompose the question and answer based on the given context. Please provide a short and concise response.",
    }
    if dataset in ['hotpotqa', 'strategyqa']:
      system_prompt = system_prompt_dict['multi-hop']
    else:
      system_prompt = system_prompt_dict['single_hop']
    user_prompt = "User Question:{question}"
    self.rewrite_template = PromptTemplate(self.config,
                                           system_prompt=system_prompt,
                                           user_prompt=user_prompt
                                           )
  def rewrite_queries(self, queries):

    rewrite_prompts = [
        self.rewrite_template.get_string(query=q)
        for q in queries
      ]
    rewrited_query_list = self.generator.generate(rewrite_prompts)
    return rewrited_query_list

  def run(self, dataset, do_eval=True, pred_process_fun=None):
    input_query = dataset.question
    optimized_query = []
    for i, q in enumerate(input_query):
      new_query = self.rq_run(input_query)
      optimized_query.append(new_query)
    retrieval_results = self.retriever.batch_search(optimized_query)

    dataset.update_output("retrieval_result", retrieval_results)


    if not self.use_fid:
      input_prompts = [
        self.prompt_template.get_string(question=q, retrieval_result=r)
        for q, r in zip(input_query, dataset.retrieval_result)
      ]

    if self.use_fid:
      print("Use FiD generation")
      input_prompts = []
      for i, item in enumerate(dataset):
        q = item.question
        docs = item.retrieval_result
        input_prompts.append([q + " " + doc['contents'] for doc in docs])
    dataset.update_output("prompt", input_prompts)

    # delete used refiner to release memory
    pred_answer_list = self.generator.generate(input_prompts)
    dataset.update_output("pred", pred_answer_list)

    dataset = self.evaluate(dataset, do_eval=do_eval, pred_process_fun=pred_process_fun)

    return dataset





